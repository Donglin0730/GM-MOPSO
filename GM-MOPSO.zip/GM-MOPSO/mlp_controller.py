# MLP控制器
import os
import pickle
import numpy as np
from pymoo.indicators.hv import HV
import time
import model

start_time_total = time.time()
np.random.seed(0) # 设置随机种子
SCENARIOS = ["fixed", "random", "real"]
COARSE_MAX_ITER = 50
FINE_MAX_ITER = 300
TOP_K_PER_SCENE = 5
INIT_SIZE = 80
N_UAV = model.N_UAV
N_VAR = N_UAV * 4
N_OBJ = 3
REF = np.array(model.ref_point)
LB = np.zeros(N_VAR)
UB = np.ones(N_VAR)
# 生成PSO算法参数的网格搜索组合
ws = np.linspace(0.4, 0.9, 5)
c1s = np.linspace(0.5, 2.5, 5)
c2s = np.linspace(0.5, 2.5, 5)
PARAMS_GRID = [(w, c1, c2) for w in ws for c1 in c1s for c2 in c2s]
os.makedirs("controller_results", exist_ok=True)

# 判断解f1是否帕累托支配解f2
def dominates(f1, f2):
    f1, f2 = np.array(f1), np.array(f2)
    return np.all(f1 <= f2) and np.any(f1 < f2)

# 从外部档案中基于到理想点的距离概率选择全局最优引导粒子
def select_gb(A_X, A_F):
    if not A_X:
        return None
    A_F_arr = np.array(A_F)
    utopia = A_F_arr.min(axis=0)
    distances = np.linalg.norm(A_F_arr - utopia, axis=1)
    probabilities = 1.0 / (distances + 1e-8)
    probabilities /= probabilities.sum()
    idx = np.random.choice(len(A_X), p=probabilities)
    return A_X[idx]

def run_mopso(w, c1, c2, seed, mode, max_iter):
    start_time_mopso = time.time()
    print(f"    [MOPSO Start] w={w:.2f}, c1={c1:.2f}, c2={c2:.2f}, mode={mode}, iter={max_iter}")
    model.make_env(mode=mode)
    local_cache = {}
    def eval_particle(x):
        x_tup = tuple(np.round(x, 6).tolist())
        if x_tup not in local_cache:
            local_cache[x_tup] = model.evaluate(x)
        return local_cache[x_tup]
    np.random.seed(seed)

    # 初始化粒子群的位置、速度和目标函数值
    X = np.random.rand(INIT_SIZE, N_VAR)
    F = np.array([eval_particle(x) for x in X])

    pop_X, pop_F = X.copy(), F.copy()
    V = np.random.uniform(-0.1, 0.1, (INIT_SIZE, N_VAR))
    pbest_X, pbest_F = pop_X.copy(), pop_F.copy() # 初始化个体历史最优

    # 初始化外部档案，存储非支配解
    A_X, A_F = [], []
    for i in range(len(X)):
        dominated = False
        to_remove = []
        for j, fj in enumerate(A_F):
            if dominates(F[i], fj):
                to_remove.append(j)
            elif dominates(fj, F[i]):
                dominated = True
                break
        if not dominated:
            A_X.append(X[i])
            A_F.append(F[i])
        for j in sorted(to_remove, reverse=True):
            A_X.pop(j)
            A_F.pop(j)

    hv_calc = HV(ref_point=REF)
    initial_hv = float(hv_calc(np.array(A_F))) if A_F else 0.0
    current_hv = initial_hv
    trajectory = [] # 记录训练轨迹

    hv_history = [current_hv]
    STAGNATION_WINDOW = 20
    no_improvement_steps = 0
    MAX_STAGNATION_COUNT = 10
    best_hv_so_far = current_hv
    no_improvement_count = 0
    patience = 10

    # 主优化循环
    for t in range(max_iter):
        progress_norm = t / max_iter
        archive_diversity_norm = len(A_F) / 100.0
        hv_range_estimate = REF[0] * REF[1] * REF[2]
        hv_progress = (current_hv - initial_hv) / (hv_range_estimate - initial_hv + 1e-8)
        if len(hv_history) > 1 and current_hv <= hv_history[-2]:
             no_improvement_steps += 1
        else:
             no_improvement_steps = 0
        convergence_indicator = min(no_improvement_steps / STAGNATION_WINDOW, 1.0)
        avg_velocity_norm = np.mean(np.linalg.norm(V, axis=1))
        max_expected_vel_norm = np.sqrt(N_VAR) * 0.2
        exploration_exploitation_balance = avg_velocity_norm / max_expected_vel_norm
        state = np.array([
            progress_norm,
            archive_diversity_norm,
            hv_progress,
            convergence_indicator,
            exploration_exploitation_balance
        ], dtype=np.float32)

        trajectory.append({'state': state, 'params': (w, c1, c2), 'hv': current_hv})
        gb = select_gb(A_X, A_F) # 选择全局最优引导粒子
        if gb is None:
            gb = pop_X[np.random.randint(0, len(pop_X))]

        # 更新粒子速度和位置
        r1, r2 = np.random.rand(2)
        V = w * V + c1 * r1 * (pbest_X - pop_X) + c2 * r2 * (gb - pop_X)
        new_pop_X = np.clip(pop_X + V, LB, UB)
        new_pop_F = np.array([eval_particle(x) for x in new_pop_X])
        pop_X = new_pop_X
        pop_F = new_pop_F
        improved_mask = np.any(pop_F < pbest_F, axis=1)
        pbest_X[improved_mask] = pop_X[improved_mask]
        pbest_F[improved_mask] = pop_F[improved_mask]

        all_X = A_X.copy() + new_pop_X.tolist()
        all_F = A_F.copy() + new_pop_F.tolist()
        dominated_flags = [False] * len(all_F)
        for i in range(len(all_F)):
            for j in range(i + 1, len(all_F)):
                if dominates(all_F[i], all_F[j]):
                    dominated_flags[j] = True
                elif dominates(all_F[j], all_F[i]):
                    dominated_flags[i] = True

        new_A_X = []
        new_A_F = []
        for k in range(len(all_F)):
            if not dominated_flags[k]:
                new_A_X.append(np.array(all_X[k]))
                new_A_F.append(all_F[k])
        A_X[:] = new_A_X
        A_F[:] = new_A_F
        current_hv = float(hv_calc(np.array(A_F))) if A_F else 0.0
        hv_history.append(current_hv)
        if len(hv_history) > STAGNATION_WINDOW + 1:
            hv_history.pop(0)

        # 记录HV指标的变化，用于判断收敛情况
        if current_hv > best_hv_so_far:
            best_hv_so_far = current_hv
            no_improvement_count = 0
        else:
            no_improvement_count += 1
    end_time_mopso = time.time()
    print(f"    [MOPSO End] Total took {end_time_mopso - start_time_mopso:.2f}s")
    return trajectory

# 检查并验证生成的样本数据格式是否正确
def check_samples():
    for mode in SCENARIOS:
        file_path = f"controller_results/{mode}.pkl"
        if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
            return False
        try:
            with open(file_path, "rb") as f:
                data = pickle.load(f)
        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            return False
        
        if not isinstance(data, list) or len(data) == 0:
            print(f"Data in {file_path} is not a list or is empty!")
            return False

        sample = data[0]
        required_keys = {'state', 'params', 'hv_gain'}
        if not isinstance(sample, dict) or not required_keys.issubset(sample.keys()):
            return False
        try:
            state = np.array(sample['state'])
            params = np.array(sample['params'])
            hv_gain = float(sample['hv_gain'])
            if state.shape != (5,) or params.shape != (3,):
                print(f"Shape mismatch in {file_path}")
                return False
            if not np.isscalar(hv_gain):
                 print(f"hv_gain in {file_path} is not a scalar")
                 return False
        except Exception as e:
            print(f"Error validating data structure in {file_path}: {e}")
            return False

        print(f"{file_path} - {len(data)} samples, structure validated.")

    return True

def main():
    print(f"Starting layered experiment at {time.strftime('%Y-%m-%d %H:%M:%S')}")
    total_start = time.time()
    final_results = {}
    for mode in SCENARIOS:
        print(f"\n--- Coarse Screening for {mode} ({COARSE_MAX_ITER} iter) ---")
        coarse_start = time.time()
        coarse_runs = []
        cnt = 0
        param_count = len(PARAMS_GRID)
        for (w, c1, c2) in PARAMS_GRID:
            cnt += 1
            print(f"  Running coarse run {cnt}/{param_count} for {mode}...")
            try:
                traj = run_mopso(w, c1, c2, seed=cnt, mode=mode, max_iter=COARSE_MAX_ITER)
                if not traj:
                    continue
                final_hv = traj[-1]['hv'] if traj else 0.0
                coarse_runs.append({
                    'params': (w, c1, c2),
                    'final_hv': final_hv,
                    'traj': traj
                })
            except Exception as e:
                print(f"    [Coarse Error] {e}")
                import traceback
                traceback.print_exc()
                continue

        coarse_end = time.time()
        print(f"--- Coarse screening for {mode} took {coarse_end - coarse_start:.2f}s ---")

        top_k_runs = sorted(coarse_runs, key=lambda x: x['final_hv'], reverse=True)[:TOP_K_PER_SCENE]
        print(f"Selected top {TOP_K_PER_SCENE} runs for fine tuning based on HV:")
        for i, run in enumerate(top_k_runs):
            print(f"  {i+1}. Params: {run['params']}, Final HV: {run['final_hv']:.4f}")

        print(f"\n--- Fine Tuning for {mode} ({FINE_MAX_ITER} iter) ---")
        fine_start = time.time()
        fine_samples = []
        for i, run in enumerate(top_k_runs):
            w, c1, c2 = run['params']
            cnt += 1
            print(f"  Running fine run {i+1}/{len(top_k_runs)} for {mode}...")
            try:
                fine_traj = run_mopso(w, c1, c2, seed=cnt, mode=mode, max_iter=FINE_MAX_ITER)
                if not fine_traj:
                    continue
                hvs = [item['hv'] for item in fine_traj]
                gains = [hvs[i+1] - hvs[i] for i in range(len(hvs)-1)] + [0.0]
                for j, item in enumerate(fine_traj):
                    fine_samples.append({
                        'state': item['state'],
                        'params': np.array([w, c1, c2]),
                        'hv_gain': gains[j]
                    })
            except Exception as e:
                print(f"    [Fine Error] {e}")
                import traceback
                traceback.print_exc()
                continue
        fine_end = time.time()
        print(f"--- Fine tuning for {mode} took {fine_end - fine_start:.2f}s ---")
        final_results[mode] = fine_samples
        with open(f"controller_results/{mode}.pkl", "wb") as f:
            pickle.dump(fine_samples, f)
        print(f"Saved {len(fine_samples)} refined samples for {mode} to controller_results/{mode}.pkl")

    all_good = check_samples()
    total_end = time.time()
    print(f"\nLayered experiment done! Total time: {total_end - total_start:.2f}s")
    if all_good:
        print("All samples are valid and correctly formatted.")
    else:
        print("Some samples failed validation. Please check the errors above.")
    print(f"Final results saved to: {os.listdir('results')}")
    print(f"End time: {time.strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    main()