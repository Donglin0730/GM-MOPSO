# GNN代理模型训练
import torch
import torch.nn as nn
import torch.nn.functional as F

class GNN_Surrogate(nn.Module):
    def __init__(self, n_uav, n_features_per_node, n_targets, hidden_dim=64):
        super(GNN_Surrogate, self).__init__()
        self.n_uav = n_uav
        self.fc_in = nn.Linear(n_features_per_node, hidden_dim) # 节点特征输入层（升维）
        self.conv1 = GCNLayer(hidden_dim, hidden_dim) # 第一层图卷积
        self.conv2 = GCNLayer(hidden_dim, hidden_dim) # 第二层图卷积
        self.pool = nn.AdaptiveAvgPool1d(1) # 全局平均池化
        self.fc_out = nn.Linear(hidden_dim, n_targets) # 输出层，预测目标值

    def forward(self, x):
        batch_size = x.size(0)
        x_flat = x.view(batch_size * self.n_uav, -1)
        x_flat = F.relu(self.fc_in(x_flat))
        x_nodes = x_flat.view(batch_size, self.n_uav, -1)
        adj_matrix = self._build_adjacency(x_nodes) # 根据节点坐标动态构建邻接矩阵
        x_nodes = self.conv1(x_nodes, adj_matrix)
        x_nodes = F.relu(x_nodes)
        x_nodes = self.conv2(x_nodes, adj_matrix)
        x_nodes = F.relu(x_nodes)
        x_global = self.pool(x_nodes.transpose(1, 2)).squeeze(-1) # 转置后池化，提取全局图特征
        y_pred = self.fc_out(x_global)
        return y_pred

    def _build_adjacency(self, node_features):
        batch_size = node_features.size(0)
        device = node_features.device
        pos = node_features[..., :3] # 提取节点的前3维作为空间坐标
        dists = torch.cdist(pos, pos, p=2) # 计算节点间的欧氏距离矩阵
        sigma_sq = 1.0 # 使用高斯核（RBF）将距离转化为邻接权重
        adj = torch.exp(-dists.pow(2) / (2 * sigma_sq))
        eye = torch.eye(self.n_uav, device=device).expand(batch_size, -1, -1)
        adj = adj * (1 - eye)
        return adj

class GCNLayer(nn.Module):
    def __init__(self, in_features, out_features):
        super(GCNLayer, self).__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, x, adj):
        ax = torch.matmul(adj, x) # 核心操作：邻接矩阵与节点特征相乘，聚合邻居信息
        ax_flat = ax.view(-1, ax.size(-1))
        out_flat = self.linear(ax_flat)
        out = out_flat.view(ax.size(0), ax.size(1), -1)
        return out

def train_gnn_surrogate(model, X_train, y_train, epochs=100, lr=0.001, verbose=True):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.MSELoss() # 使用均方误差作为损失函数
    model.train()
    for epoch in range(epochs):
        optimizer.zero_grad()
        y_pred = model(X_train)
        loss = criterion(y_pred, y_train)
        loss.backward()
        optimizer.step()

@torch.no_grad()
def predict_gnn_surrogate(model, X_test):
    model.eval() # 切换到评估模式
    y_pred = model(X_test)
    return y_pred