# GM-MOPSO主算法
import torch.nn as nn
import numpy as np
import torch
import os
import json
import time
from scipy.stats import qmc
from sklearn.preprocessing import StandardScaler
from pymoo.indicators.hv import HV
from pymoo.indicators.igd import IGD
import model
from gnn_surrogate import GNN_Surrogate, train_gnn_surrogate, predict_gnn_surrogate

# 全局配置参数
USE_PHYSICAL_FEATURES = True
USE_ADAPTIVE_PARAMS = True
INIT_SIZE = 80 # 初始样本数量（用于训练代理模型）
MAX_ITER = 500 # 最大迭代次数
EVALS_PER_ITER = 40 # 每次迭代的真实评估次数
MAX_ARCHIVE_SIZE = 300 # 外部存档的最大容量
BUDGET = 20000 # 总评估预算

# 计算物理特征（替代原始坐标，作为GNN输入）
def compute_physical_features(X, env_config):
    N_uav = env_config['N_UAV']
    user_positions = env_config['ue_positions']
    ris_positions = env_config['ris_pos']
    P_max = env_config['P_max']
    alpha_pl = model.alpha_los
    batch_size = X.shape[0]
    feats = np.zeros((batch_size, N_uav * 5))
    for b_idx in range(batch_size):
        x_p = X[b_idx].reshape(N_uav, 4)
        pos = x_p[:, :3] # 位置 (x, y, z)
        pow = x_p[:, 3] # 功率
        user_c = np.mean(user_positions, axis=0) # 用户中心
        d_ris = np.linalg.norm(pos[:, None, :] - ris_positions[None, :, :], axis=2)
        d_user_c = np.linalg.norm(pos - user_c, axis=1)
        p_feats = []
        for i in range(N_uav):
            d_nr = np.min(d_ris[i])
            d_uc_h = np.linalg.norm(pos[i, :2] - user_c[:2])
            los_f = 1.0 if env_config['los_strategy'].is_los(pos[i], user_c) else 0.0 # 是否处于视距
            # 计算干扰
            o_pos = np.delete(pos, i, axis=0)
            o_pow = np.delete(pow, i)
            d_o = np.linalg.norm(pos[i] - o_pos, axis=1)
            d_o_safe = np.maximum(d_o, 1.0)
            # 基于距离的路径损耗计算干扰值
            interf = np.sum(o_pow / (d_o_safe ** alpha_pl))
            p_feats.extend([d_nr, d_uc_h, los_f, interf, pow[i]])
        feats[b_idx] = np.array(p_feats)
    
    return feats.astype(np.float32)

# 计算搜索状态（作为自适应控制器的输入）
def compute_search_state(iter, arch_f, ref_p, max_iter, max_arch_s):
    t_norm = iter / max_iter
    arch_size_norm = len(arch_f) / max_arch_s if max_arch_s > 0 else 0.0 # 存档大小占比
    if arch_f:
        f_arr = np.array(arch_f)
        std_devs = np.std(f_arr, axis=0)
        std_mean = np.mean(std_devs)
        std_norm = min(std_mean / 100.0, 1.0)
        ranges = np.ptp(f_arr, axis=0)
        mean_range = np.mean(ranges)
        spr_norm = min(mean_range / 1e6, 1.0)
        try:
            hv_calc = HV(ref_point=ref_p)
            hv = hv_calc(f_arr) # 超体积指标
        except:
            hv = np.prod(np.ptp(f_arr, axis=0)) if f_arr.shape[0] > 1 else 0.0
        hv_norm = min(hv / 1e6, 1.0)
    else:
        hv_norm = 0.0
        std_norm = 0.0
        spr_norm = 0.0
    
    # 返回状态向量
    return np.array([[t_norm, arch_size_norm, hv_norm, std_norm, spr_norm]], dtype=np.float32)

# 从存档中选择全局最优解
def select_gb(A_X, A_F):
    if len(A_X) == 0:
        return A_X[0]
    A_F_arr = np.array(A_F)
    utopia = np.min(A_F_arr, axis=0) # 乌托邦点
    dists = np.linalg.norm(A_F_arr - utopia, axis=1)
    probs = (1.0 / (dists + 1e-8)) # 距离越近，概率越高
    probs /= np.sum(probs)
    idx = np.random.choice(len(A_X), p=probs)
    return A_X[idx]

#自适应控制器（MLP网络，用于动态调整PSO参数）
class AdaptiveController(nn.Module):
    def __init__(self, input_dim=5, hidden_dim=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 3), # 输出维度：w, c1, c2
            nn.Sigmoid()
        )
    def forward(self, s):
        out = self.net(s)
        # 映射到实际参数范围
        w = 0.4 + 0.5 * out[:, 0]
        c1 = 0.5 + 2.0 * out[:, 1]
        c2 = 0.5 + 2.0 * out[:, 2]
        return torch.stack([w, c1, c2], dim=1)

# 判断解f1是否Pareto支配解f2
def dominates(f1, f2):
    f1, f2 = np.array(f1), np.array(f2)
    return np.all(f1 <= f2) and np.any(f1 < f2)

# 评估预算管理器
class EvalBudget:
    def __init__(self, total):
        self.total = total
        self.count = 0
    def consume(self, n):
        self.count += n
    def is_exhausted(self):
        return self.count >= self.total

# 计算解集的Spacing指标
def calculate_spacing(front):
    if len(front) < 2:
        return float('inf')
    from scipy.spatial.distance import pdist, squareform
    dists = pdist(front)
    sq_dists = squareform(dists)
    np.fill_diagonal(sq_dists, np.inf)
    min_dists = np.min(sq_dists, axis=1)
    mean_d = np.mean(min_dists)
    spacing = np.sqrt(np.mean((min_dists - mean_d) ** 2))
    return spacing

# 单次运行主函数
def run_gmmopso_single_run(seed=0, mode="random"):
    start_time = time.time()
    print(f"[{time.strftime('%H:%M:%S')}] Starting GM-MOPSO (seed={seed})")
    np.random.seed(seed)
    torch.manual_seed(seed)
    dem, x_grid, y_grid, region_grid, ris_pos = model.make_env(seed=seed, mode=mode) # 环境初始化
    env_config = {
        'N_UAV': model.N_UAV,
        'ue_positions': model._USER_POS,
        'ris_pos': model._RIS_POS,
        'P_max': model.P_max,
        'los_strategy': model._LOS_STRATEGY
    }

    # 参数设置
    dim = 4 * model.N_UAV
    lb = np.array([model.X_min, model.Y_min, model.H_min, model.P_min] * model.N_UAV)
    ub = np.array([model.X_max, model.Y_max, model.H_max, model.P_max] * model.N_UAV)

    # 生成初始种群 (LHS)
    sampler = qmc.LatinHypercube(d=dim)
    X_init_unit = sampler.random(n=INIT_SIZE)
    X_init = qmc.scale(X_init_unit, lb, ub)

    # 计算初始物理特征并训练GNN代理模型
    Phi_init = compute_physical_features(X_init, env_config)
    F_init = np.array([model.evaluate(x) for x in X_init])
    surrogate = GNN_Surrogate(n_uav=model.N_UAV, n_features_per_node=5, n_targets=3, hidden_dim=64)
    sc_x = StandardScaler() # 特征标准化
    sc_y = StandardScaler() # 标签标准化

    Phi_sc_init = sc_x.fit_transform(Phi_init)
    F_sc_init = sc_y.fit_transform(F_init)
    Phi_sc_t = torch.tensor(Phi_sc_init, dtype=torch.float32)
    F_sc_t = torch.tensor(F_sc_init, dtype=torch.float32)

    # 预训练代理模型
    train_gnn_surrogate(surrogate, Phi_sc_t, F_sc_t, epochs=500, verbose=False)

    # 初始化自适应控制器
    ctrl = None
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if USE_ADAPTIVE_PARAMS:
        ctrl = AdaptiveController(input_dim=5, hidden_dim=32)
        ckpt_path = "controller_results/pretrained_mlp.pth"
        if os.path.exists(ckpt_path):
            ctrl.load_state_dict(torch.load(ckpt_path, map_location=device))
            print("Loaded pretrained MLP controller.")
        else:
            print("Warning: pretrained_mlp.pth not found. Using untrained MLP.")
        ctrl.eval().to(device)
    
    # 粒子群初始化
    pop = X_init.copy()
    V = np.random.uniform(-1, 1, (INIT_SIZE, dim))
    pb_x = X_init.copy()
    pb_f = F_init.copy()

    A_X, A_F = [], [] # 初始化外部存档
    for i in range(len(X_init)):
        dom = False
        rm = []
        # 非支配排序逻辑：移除被支配的旧解，若不被支配则加入存档
        for j, fj in enumerate(A_F):
            if dominates(F_init[i], fj):
                rm.append(j)
            elif dominates(fj, F_init[i]):
                dom = True
                break
        if not dom:
            A_X.append(X_init[i])
            A_F.append(F_init[i])
        
        # 清理被支配的旧解
        for idx in sorted(rm, reverse=True):
            A_X.pop(idx)
            A_F.pop(idx)

        if len(A_X) > MAX_ARCHIVE_SIZE:
            A_X = A_X[:MAX_ARCHIVE_SIZE]
            A_F = A_F[:MAX_ARCHIVE_SIZE]
    
    # 预算管理器
    budget = EvalBudget(BUDGET)
    budget.consume(len(X_init))
    hist = []

    # 主循环
    for t in range(MAX_ITER):
        if budget.is_exhausted():
            print(f"[{time.strftime('%H:%M:%S')}] Budget exhausted, terminating early")
            break
        
        # --- 代理模型预测阶段 ---
        Phi_pop = compute_physical_features(pop, env_config)
        Phi_sc_pop = sc_x.transform(Phi_pop)
        Phi_sc_t_pop = torch.tensor(Phi_sc_pop, dtype=torch.float32)
        F_pred_sc_t = predict_gnn_surrogate(surrogate, Phi_sc_t_pop)
        F_pred = sc_y.inverse_transform(F_pred_sc_t)
        
        # --- 参数自适应调整阶段 ---
        if USE_ADAPTIVE_PARAMS and ctrl is not None:
            st = compute_search_state(t, A_F, model.ref_point, MAX_ITER, MAX_ARCHIVE_SIZE)
            with torch.no_grad():
                ps_t = ctrl(torch.tensor(st, dtype=torch.float32))
                w, c1, c2 = ps_t[0, 0].item(), ps_t[0, 1].item(), ps_t[0, 2].item()
        else:
            w = 0.9 - 0.5 * (t / MAX_ITER)
            c1 = c2 = 2.0
        
        # --- 粒子群更新 ---
        gb = select_gb(A_X, A_F) if A_X else pop[np.argmin(F_pred[:, 0])]
        r1, r2 = np.random.rand(2)
        V = w * V + c1 * r1 * (pb_x - pop) + c2 * r2 * (gb - pop)
        pop_new = np.clip(pop + V, lb, ub)
        pop = pop_new
        
        # --- 基于代理模型的筛选 (挑选最有潜力的个体进行真实评估) ---
        evl_idx_scs = [(i, F_pred[i, 0]) for i in range(len(pop))]
        evl_idx_sort = sorted(evl_idx_scs, key=lambda x: x[1])
        sel_idx = [isc[0] for isc in evl_idx_sort[:EVALS_PER_ITER]]
        X_ev = pop[sel_idx]
        F_ev = np.array([model.evaluate(x) for x in X_ev])
        budget.consume(len(X_ev))
        
        # --- 更新个体最优和外部存档 ---
        for i, idx in enumerate(sel_idx):
            if dominates(F_ev[i], pb_f[idx]):
                pb_x[idx] = X_ev[i]
                pb_f[idx] = F_ev[i]
            dom = False
            rm = []
            for j, fj in enumerate(A_F):
                if dominates(F_ev[i], fj):
                    rm.append(j)
                elif dominates(fj, F_ev[i]):
                    dom = True
                    break
            if not dom:
                A_X.append(X_ev[i])
                A_F.append(F_ev[i])
            for idx_r in sorted(rm, reverse=True):
                A_X.pop(idx_r)
                A_F.pop(idx_r)
            if len(A_X) > MAX_ARCHIVE_SIZE:
                A_X = A_X[:MAX_ARCHIVE_SIZE]
                A_F = A_F[:MAX_ARCHIVE_SIZE]
        
        # --- 记录指标 ---
        curr_hv = 0.0
        if A_F:
            try:
                hv_calc = HV(ref_point=np.array(model.ref_point))
                curr_hv = float(hv_calc(np.array(A_F)))
            except Exception:
                f_a = np.array(A_F)
                curr_hv = np.prod(np.ptp(f_a, axis=0)) if f_a.shape[0] > 1 else 0.0
            A_F_arr = np.array(A_F)
            best_f1 = float(np.min(A_F_arr[:, 0]))
            best_f2 = float(np.min(A_F_arr[:, 1]))
            best_f3 = float(np.min(A_F_arr[:, 2]))
        else:
            best_f1 = best_f2 = best_f3 = np.inf
        hist.append([budget.count, len(A_F), curr_hv, best_f1, best_f2, best_f3])
        
        # --- 代理模型重训练 (每隔50代) ---
        if t % 50 == 0 and t > 0:
            A_X_np = np.vstack([X_init, np.array(A_X)])
            A_F_np = np.vstack([F_init, np.array(A_F)])
            A_Phi_np = compute_physical_features(A_X_np, env_config)
            A_Phi_sc_np = sc_x.fit_transform(A_Phi_np)
            A_F_sc_np = sc_y.fit_transform(A_F_np)
            A_Phi_sc_t = torch.tensor(A_Phi_sc_np, dtype=torch.float32)
            A_F_sc_t = torch.tensor(A_F_sc_np, dtype=torch.float32)
            # 增量训练
            train_gnn_surrogate(surrogate, A_Phi_sc_t, A_F_sc_t, epochs=300, verbose=False)
        
        # --- 打印日志 ---
        if (t + 1) % 50 == 0 or t == 0:
            print(f"[{time.strftime('%H:%M:%S')}] Iter {t+1}/{MAX_ITER} | Evals: {budget.count}/{BUDGET} | Arch: {len(A_F)}")
            if A_F:
                A_F_arr = np.array(A_F)
                utopia_f = np.min(A_F_arr, axis=0)
                dists_f = np.linalg.norm(A_F_arr - utopia_f, axis=1)
                best_i = int(np.argmin(dists_f))
                x_opt = A_X[best_i]
                f_opt = A_F[best_i]
                print(f"[{time.strftime('%H:%M:%S')}] Optimal solution: {f_opt}")
            else:
                x_opt = f_opt = None
                best_i = -1
                print("Warning: Archive is empty.")
    
    # 结果计算与保存
    end_time = time.time()
    elapsed = end_time - start_time
    final_hv = 0.0
    final_igd = float('inf')
    final_spacing = float('inf')
    if A_F:
        A_F_np = np.array(A_F)
        try:
            hv_calc = HV(ref_point=np.array(model.ref_point))
            final_hv = float(hv_calc(A_F_np))
        except Exception:
            f_a = A_F_np
            final_hv = np.prod(np.ptp(f_a, axis=0)) if f_a.shape[0] > 1 else 0.0
        
        try:
            # 计算IGD指标 (使用参考集)
            ref_pf = np.load(f"reference_sets/reference_set_{mode}.npy")
            igd_calc = IGD(ref_pf)
            final_igd = float(igd_calc.do(A_F_np))
        except Exception as e:
            print(f"IGD calculation failed: {e}")
        
        try:
            final_spacing = float(calculate_spacing(A_F_np))
        except Exception as e:
            print(f"Spacing calculation failed: {e}")
    
    # 创建目录并保存结果
    rn = f"gm_mopso_seed{seed}"
    sd = os.path.join("gm_mopso_results", mode)
    os.makedirs(sd, exist_ok=True)
    
    A_F_arr = np.array(A_F) if A_F else np.empty((0, 3))
    np.save(os.path.join(sd, f"{rn}_A_F.npy"), A_F_arr)
    
    if A_X:
        A_X_arr = np.array(A_X)
        solutions = np.hstack([A_X_arr, A_F_arr])
        np.save(os.path.join(sd, f"{rn}_solutions.npy"), solutions)
    
    if hist:
        np.save(os.path.join(sd, f"{rn}_history.npy"), np.array(hist))
    
    # 保存元数据
    mt = {
        "algorithm": "GM-MOPSO",
        "seed": int(seed),
        "use_physical_features": bool(USE_PHYSICAL_FEATURES),
        "use_adaptive_params": bool(USE_ADAPTIVE_PARAMS),
        "problem": "UAV-RIS Coverage",
        "n_uav": int(model.N_UAV),
        "budget": int(BUDGET),
        "eval_count": int(budget.count),
        "archive_size": len(A_F),
        "final_hv": final_hv,
        "final_igd": final_igd,
        "final_spacing": final_spacing,
        "ref_point": list(model.ref_point),
        "total_time_sec": float(elapsed),
        "max_iter": MAX_ITER,
        "init_size": INIT_SIZE,
        "evals_per_iter": EVALS_PER_ITER
    }

    if A_F:
        A_F_arr_meta = np.array(A_F)
        utopia_f_meta = np.min(A_F_arr_meta, axis=0)
        dists_f_meta = np.linalg.norm(A_F_arr_meta - utopia_f_meta, axis=1)
        best_i_meta = int(np.argmin(dists_f_meta))
        x_opt_meta = A_X[best_i_meta]
        f_opt_meta = A_F[best_i_meta]
        mt["compromise_solution_f"] = f_opt_meta.tolist()
        mt["compromise_solution_x"] = x_opt_meta.tolist()
        comp_data = {
            "decision_vector": x_opt_meta.tolist(),
            "objective_values": f_opt_meta.tolist(),
            "archive_index": best_i_meta
        }
        with open(os.path.join(sd, f"{rn}_compromise.json"), "w") as f:
            json.dump(comp_data, f, indent=4)
    else:
        mt["compromise_solution_f"] = None
        mt["compromise_solution_x"] = None
    
    with open(os.path.join(sd, f"{rn}_meta.json"), "w") as f:
        json.dump(mt, f, indent=4)
    
    return A_X, A_F

if __name__ == "__main__":
    scenarios = ["fixed", "random", "real"]
    num_runs = 20 # 运行20轮
    seeds = list(range(num_runs))
    for mode in scenarios: # 遍历三种场景
        print(f"[{time.strftime('%H:%M:%S')}] ({num_runs} runs)...")
        for i, seed in enumerate(seeds):
            print(f"[{time.strftime('%H:%M:%S')}] Starting Run {i+1}/{num_runs} (seed={seed})...")
            A_X, A_F = run_gmmopso_single_run(seed=seed, mode=mode)
            print(f"[{time.strftime('%H:%M:%S')}] Run {i+1} (seed={seed}) completed.\n")
        print(f"[{time.strftime('%H:%M:%S')}] Scenario '{mode}' completed.")