# 预训练MLP控制器
import pickle
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import os

class AdaptiveController(nn.Module):
    def __init__(self, input_dim=5, hidden_dim=32):
        super(AdaptiveController, self).__init__()
        # 构建MLP网络
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 3),
            nn.Sigmoid()
        )

    def forward(self, s):
        out = self.net(s)
        w = 0.4 + 0.5 * out[:, 0] 
        c1 = 0.5 + 2.0 * out[:, 1]
        c2 = 0.5 + 2.0 * out[:, 2]
        return torch.stack([w, c1, c2], dim=1)

def train_and_save_controller():
    all_states = []
    all_params = []
    for scenario in ["fixed", "random", "real"]:
        file_path = f"controller_results/{scenario}.pkl"
        if os.path.exists(file_path):
            print(f"  Loading {file_path}...")
            with open(file_path, 'rb') as f:
                data = pickle.load(f)
            # 提取状态和参数数据
            states = np.array([d['state'] for d in data])
            params = np.array([d['params'] for d in data])
            all_states.append(states)
            all_params.append(params)
            print(f"    Loaded {len(data)} samples from {scenario}.")
        else:
            print(f"  Warning: File {file_path} not found. Skipping.")
    
    if not all_states:
        raise FileNotFoundError("No .pkl files found . Did you run mlp_controller.py?")

    X = np.vstack(all_states).astype(np.float32)
    Y = np.vstack(all_params).astype(np.float32)

    print(f"Total training samples: {len(X)}")
    X_tensor = torch.tensor(X)
    Y_tensor = torch.tensor(Y)
    dataset = TensorDataset(X_tensor, Y_tensor)
    dataloader = DataLoader(dataset, batch_size=64, shuffle=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"Using device: {device}")
    # 初始化模型、损失函数和优化器
    controller = AdaptiveController(input_dim=5, hidden_dim=32).to(device)
    criterion = nn.MSELoss() # 均方误差损失
    optimizer = optim.Adam(controller.parameters(), lr=0.001)

    print("Starting training...")
    controller.train()
    num_epochs = 500
    for epoch in range(num_epochs):
        epoch_loss = 0.0
        for batch_states, batch_params in dataloader:
            batch_states, batch_params = batch_states.to(device), batch_params.to(device)
            optimizer.zero_grad()
            predicted_params = controller(batch_states)
            loss = criterion(predicted_params, batch_params)
            loss.backward() # 反向传播
            optimizer.step() # 更新参数
            epoch_loss += loss.item()
    print("Training completed.")
    # 保存训练好的模型
    save_path = "controller_results/pretrained_mlp.pth"
    torch.save(controller.state_dict(), save_path)

if __name__ == "__main__":
    train_and_save_controller()